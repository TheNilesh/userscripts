// ==UserScript==
// @name         Show average hours
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://app17.workline.hr/ams/AmsViewEmployeeCalenderEmp.aspx
// @grant        GM_xmlhttpRequest
// @grant        GM_log
// ==/UserScript==

(function() {
    'use strict';
    var oldFunction = unsafeWindow.callYearCalendar;

    unsafeWindow.callYearCalendar = function(flag) {
        alert('Hijacked! Argument was ' + flag + '.');
        return oldFunction(flag);
    };
//     var ret = GM_xmlhttpRequest({
//         method: "GET",
//         url: "https://app17.workline.hr/AMS/AMSViewEmployeeCalendarSubEmp.aspx?FDate=01-October-2019&Flag=P&UC=1160",
//         onload: function(res) {
//             GM_log(res.responseText);
//         },
//         onerror: function(res) {
//             var msg = "An error occurred."
//             + "\nresponseText: " + res.responseText
//             + "\nreadyState: " + res.readyState
//             + "\nresponseHeaders: " + res.responseHeaders
//             + "\nstatus: " + res.status
//             + "\nstatusText: " + res.statusText
//             + "\nfinalUrl: " + res.finalUrl;
//             GM_log(msg);
//         }
//     });
})();