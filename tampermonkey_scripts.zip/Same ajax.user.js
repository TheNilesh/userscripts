// ==UserScript==
// @name         Same ajax
// @namespace    http://tampermonkey.net/
// @version      0.1
// @run-at       document-idle
// @description  try to take over the world!
// @author       You
// @match        https://app17.workline.hr/ams/AmsViewEmployeeCalenderEmp.aspx
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    function durationInDec(timeDuration) {
        var td = timeDuration.split(':');
        return {
            hours: parseInt(td[0]),
            minutes: parseInt(td[1])
        };
    }
    var passDate, pagename = '', UC = '', flag = 'P';
    pagename = $('#HidPageName').val();
    UC = $('#HidUsercode').val();
    // passDate = '01-November-2019';
    passDate = $('#HidPDate').val();
    $.ajax({
            url: '/AMS/AMSViewEmployeeCalendarSub' + pagename + '.aspx?FDate=' + passDate + '&Flag=' + flag + '&UC=' + UC,
            success: function (response) {
                debugger;
                var pResp = '<div>' + response + '</div>';
                var dates = $(pResp).find("td[data-title='Date']").map(function(){ return this.innerText.trim();}).get();
                var shifts = $(pResp).find("td[data-title='Shift']").map(function(){ return this.innerText.trim();}).get();
                var workingHrs = $(pResp).find("td[data-title='Working Hrs.']").map(function(){ return this.innerText.trim();}).get();
                var leavesPending = $(pResp).find("td[data-title='Leave Pending']").map(function(){ return this.innerText.trim();}).get();
                var leavesApproved = $(pResp).find("td[data-title='Leave Approved']").map(function(){ return this.innerText.trim();}).get();

                //Remove values for records before 21st of the month
                dates = dates.slice(20);
                shifts = shifts.slice(20);
                workingHrs = workingHrs.slice(20);
                leavesPending = leavesPending.slice(20);
                leavesApproved = leavesApproved.slice(20);

                var totalHours = 0, totalMinutes = 0;
                var i;
                var workingDaysCount = 0;
                for (i = 0; i < dates.length; i++) {
                    if(shifts[i] === 'GS' && leavesPending[i] === '' && leavesApproved[i] === '') {
                       var durInDec = durationInDec(workingHrs[i]);
                       totalHours += durInDec.hours;
                       totalMinutes += durInDec.minutes;
                       workingDaysCount++;
                    }
                }
                console.log(workingDaysCount);
                console.log(totalHours, ':', totalMinutes);

                var averageWorkingHours = totalHours/workingDaysCount;
                var averageWorkingMinutes = totalMinutes/workingDaysCount;

                //todo: Add into dom
            }
        });
})();